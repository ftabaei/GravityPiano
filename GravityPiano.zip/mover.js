class Mover {
  constructor(x, y, m) {
    this.pos = createVector(x, y);
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);
    this.mass = m + 1;
    this.r = sqrt(this.mass) * 5;
    this.color = color(random(50, 255), random(50, 255), random(50, 255), 100);
    this.overIt = false;


  }

  friction() {
    let diff = height - (this.pos.y + this.r);
    if (diff < 1) {

      //Normalize the velocity vector
      let friction = this.vel.copy();
      friction.normalize();
      friction.mult(-1);


      let normal = this.mass;
      friction.setMag(mu * normal);

      this.applyForce(friction);
    }

  }

  update() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.mult(0);
  }

  applyForce(force) {
    if (this.over) {
      let f = p5.Vector.div(force, this.mass);
      this.acc.add(f);
    }
  }

  edges() {
    if (this.pos.y >= height - this.r) {
      this.pos.y = height - this.r;
      this.vel.y *= -1;
      if (pow(this.vel.y, 2) > 0.1) {
        songs[22-this.mass].play();
      }
    }
    if (this.pos.y <= this.r) {
      this.pos.y = this.r;
      this.vel.y *= -1;
      if (pow(this.vel.y, 2) > 0.1) {
        songs[22-this.mass].play();
      }
    }

    if (this.pos.x >= width - this.r) {
      this.pos.x = width - this.r;
      this.vel.x *= -1;
      if (pow(this.vel.x, 2) > 0.1) {
        songs[22-this.mass].play();
      }
    }

    if (this.pos.x <= this.r) {
      this.pos.x = this.r;
      this.vel.x *= -1;
      if (pow(this.vel.x, 2) > 0.1) {
        songs[22-this.mass].play();
      }
    }
  }

  mouseOver() {
    let mouse = createVector(mouseX, mouseY);
    let distance = dist(this.pos.x, this.pos.y, mouse.x, mouse.y);
    if (distance < this.r && this.vel.mag() == 0) {
      this.over = true;

    } else if (distance < this.r && this.vel.mag() != 0) {
      this.vel.setMag(0);
    }
  }

  show() {
    stroke(255);
    fill(this.color);
    ellipse(this.pos.x, this.pos.y, 2 * this.r);
  }

}