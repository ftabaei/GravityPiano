let movers = [];
let mu = 0.01;
let songs = [];

function preload() {
  for (let i = 0; i < 22; i++) {
    let path = 'assets/' + i + '.mp3';
    songs[i] = loadSound(path);
  }
}

function setup() {
  createCanvas(500, 500);
  for (let i = 0; i < 22; i++) {
    movers[i] = new Mover(random(30, width - 30), random(30, height - 30), int(i));
  }
}

function draw() {
  background(150);


  for (let mover of movers) {
    if (mouseIsPressed) {
      let wind = createVector(0.5, 0);
      mover.applyForce(wind);
    }

    let gravity = createVector(0, 0.03);

    let weight = p5.Vector.mult(gravity, mover.mass);
    mover.applyForce(weight);

    mover.friction();
    mover.update();
    mover.edges();
    mover.show();
    mover.mouseOver();
  }

  noStroke();
  fill(20);
  textAlign(CENTER);
  text("Hold the left mouse button to apply wind", width / 2, 20);

}